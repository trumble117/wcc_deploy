'''
@author Johnathon W. Trumble
@contact john.trumble@oracle.com
@version 0.9b June 26th, 2014
@summary Control script for starting/stopping various WebLogic domain processes
         including AdminServer, and NodeManager
'''
import sys
import os
import socket
import time
import ConfigParser
import urllib2

'''
    @summary: Main function.
              Parses input and performs tasks appropriate for the request.
              In the case of invalid input, displays a help function.
'''
def main(argv):
    import getopt
    
    # Configuration file contains all relevant properties needed to perform tasks
    global config
    config = ConfigParser.RawConfigParser()
    config.read('/home/oracle/wls_scripts/serverproperties.cfg')
    
    # Grab this machine's associated domain from a server environment variable
    global domain
    domain = os.environ['WLS_DOMAIN']
    
    # Map options to a tuple
    try:
        opts, args = getopt.getopt(argv, "h", ["help", "start=", "stop=", "status="])
    except getopt.GetoptError, err:
        print str(err)
        usage()
        sys.exit(2)

    # Spit out superfluous command line arguments
    unusedArgs = ", ".join(args)
    if args:
        print ('Not using command-line arguments: ' + unusedArgs + '\n')
    if not opts:
        usage()
        sys.exit(2)
    for opt, arg in opts:
        if opt in ("-h", "--help"):
            usage()
            sys.exit()
        elif opt == "--start":
            if arg == "nodemanager":
                startNodeManager()
            elif arg == "admin":
                startAdminServer()
            else:
                print ('Invalid target %s!')%arg
                usage()
                sys.exit(2)
        elif opt == "--stop":
            if arg == "nodemanager":
                stopNodeManager()
            elif arg == "admin":
                stopAdminServer()
            else:
                print ('Invalid target %s!'%arg)
                usage()
                sys.exit(2)
        elif opt == "--status":
            if arg == "nodemanager":
                return nmStatus()
            elif arg == "admin":
                return adminStatus()
            else:
                print ('Invalid target %s!'%arg)
                usage()
                sys.exit(2)
    return

'''
    @summary: Starts a nodemanager process on the local machine.
              First a check is performed to ensure that a nodemanager isn't
              already running.
              Output is piped into a machine-specific log file.
              Reliant upon the configuration file being properly populated.
''' 
def startNodeManager():
    if ( isNodeManagerRunning(config.get(domain, 'NM_PORT'))):
        errMsg = "NodeManager is already running!"
        raise Exception(errMsg)
    else:
        hostname_long = os.environ['HOSTNAME'].split('.')
        hostname = hostname_long[0] 
        nmHome = config.get(domain, 'FMW_HOME') + '/wlserver_10.3/server'
        log ('Starting nodemanager...')
        logFileName = config.get(domain, 'LOG_DIR') + "/" + hostname + "_nodemanager.log"
        log ('Standard output redirected to %s'%logFileName)
        script = '(cd %s/bin; ./startNodeManager.sh > %s 2>&1 &)'%(nmHome, logFileName)
        os.system(script)
            
        psScript = 'ps -ef | grep weblogic.NodeManager | grep -v grep | grep java > /dev/null'
        status=True
        delay=20
        startTime=0
        while (not isNodeManagerRunning(config.get(domain, 'NM_PORT'))):
            # Abort if the java process is dead
            startTime+=(delay*.1)
                        
            progressBar(delay)
            status = os.system(psScript)
            if (status > 0):
                errMsg = 'NodeManager failed to start please check log file [%s] for details'%logFileName
                raise Exception (errMsg)            
            else:
                print '=',
        print ('[DONE]')
        print ('Time to start: %s seconds'%startTime)
        print 
    return

'''
    @summary: Kills a currently running nodemanager process.
              Assumes only one nodemanger can be running.
''' 
def stopNodeManager():
    pid = ""
    for line in os.popen("ps xa | grep weblogic.NodeManager | grep -v grep"):
        fields = line.split()
        pid = fields[0]
    
    if (pid):
        os.kill(int(pid), 9)
        print ('Killed NodeManager process: %s'%pid)    
    else:
        errMsg = 'Nodemanager was not found to be running on this system!'
        raise Exception (errMsg)
    return

'''
    @summary: Starts a AdminServer process on the local machine.
              First a check is performed to ensure that a AdminServer isn't
              already running.
              Output is piped into a machine-specific log file.
              Reliant upon the configuration file being properly populated.
''' 
def startAdminServer():
    if (isServerRunning(config.get(domain, 'ADMIN_PORT'), os.environ['HOSTNAME'])):
        errMsg = 'AdminServer is already running'
        raise Exception (errMsg)
        
    log ('Starting AdminServer')
    hostname_long = os.environ['HOSTNAME'].split('.')
    hostname = hostname_long[0]
    this_ip = socket.gethostbyname(hostname_long[0])
    domainHome = config.get(domain, 'DOMAIN_HOME')
    logFileName = config.get(domain, 'LOG_DIR') + "/" + hostname + "_AdminServer.log"
    log ('Standard output redirected to %s'%logFileName)   
        
    script = '(cd %s; ./startWebLogic.sh > %s 2>&1 &)'%(domainHome,logFileName)
    os.system(script)
    psScript = 'ps -ef | grep AdminServer | grep -v grep | grep java > /dev/null 2>&1'
                    
    status=True
    delay=50
    startTime=0
    while ( not isServerRunning(config.get(domain, 'ADMIN_PORT'), this_ip)):
        # Abort if the java process is dead
        startTime+=(delay*.1)
            
        progressBar()
        status = os.system(psScript)
        if (status > 0):
            errMsg =  'AdminServer server failed to start please check log file [%s] for details'%logFileName
            raise Exception (errMsg)            
        else:
            print '=',
    print ('[DONE]')
    print ('Time to start: %s seconds'%startTime)
    return

'''
    @summary: Instantiates shutdown of a currently running AdminServer instance.
''' 
def stopAdminServer():
    if (not isNodeManagerRunning(config.get(domain, 'ADMIN_PORT'))):
        log ('AdminServer is already stopped.')
        return
    domainHome = config.get(domain, 'DOMAIN_HOME')
    script = 'cd %s/bin; ./stopWebLogic.sh 2>&1'%domainHome
    p = os.popen(script, "r")
    while True:
        ln = p.readline();
        if not ln:
            break
        else:
            print ln
    return

'''
    @summary: Returns a status indicating whether an AdminServer is running or not for
              this machine's domain.
''' 
def adminStatus():
    # Added using a specific server name, since in the OAM domain, Admin doesn't listen on localhost
    hostname_long = os.environ['HOSTNAME'].split('.')
    this_ip = socket.gethostbyname(hostname_long[0])
    status = isServerRunning(config.get(domain, 'ADMIN_PORT'), this_ip) and "Running" or "Shutdown"
    print ('AdminServer is %s'%(status))
    if status == 'Shutdown':
        return 1
    return

'''
    @summary: Returns a status indicating whether a nodemanager process is running or
              not on this machine.
'''
def nmStatus():
    status = isNodeManagerRunning(config.get(domain, 'NM_PORT')) and "Running" or "Shutdown"
    print ('NodeManager is %s'%(status))
    if status == 'Shutdown':
        return 1
    return
    
def log(strr, newLine=True):
    if (newLine):
        print (strr)
    else:
        print (strr),
        sys.stdout.flush()
        
'''
    @summary: Check if server is running on the given portNumber.
              Uses HTTP connection.
    @param portNumber: Port number to check
    @param hostName: Name of the host to connect to, default is localhost  
'''
def isServerRunning(portNumber, hostName='127.0.0.1'):
    
    try:
        f = urllib2.urlopen('http://%s:%s/'%(hostName,portNumber))
        f.close()
        return True
       
    
    except urllib2.HTTPError, e:
        ''' Http error indicates, we were able to open a connection
            but it returned some HTTP error such as 404 etc.
            Treat it as server running. If anything greater than 500
            treat it as stopped
        '''
        if (e.code > 500):
            return False
        else:
            return True
    except urllib2.URLError:        
        return False
    
'''
    @summary: Check if nodemanager is running on the given portNumber.
              Uses socket connection.
    @param portNumber: Port number to check
    @param hostName: Name of the host to connect to, default is localhost  
'''   
def isNodeManagerRunning(portNumber, hostName='127.0.0.1'):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.connect((hostName, int(portNumber)))
        s.close()
        return True
    except:
        return False

'''
    @summary: spinCursor and progressBar are used during process start.
              Provides visual output during an operation to indicate
              that the process hasn't died, and is still working.
'''    
def spinCursor():
    cursor='|/-\|/-\\'
    i = 0
    while 1:
        yield cursor[i]
        i = (i + 1) % len(cursor)
        
def progressBar(spins=50):
    counter=0
    sys.stdout.write('| ')
    for c in spinCursor():
        counter+=1
        sys.stdout.write(c)
        sys.stdout.write(' ')
        sys.stdout.flush()
        time.sleep(0.1)
        sys.stdout.write('\b\b')
        if( counter==50 ):
                sys.stdout.write('\b\b')
                break

'''
    @summary: Displays a help function in case the user requires it or
              provided invalid input.
'''
def usage():
    # A handy help function
    print("usage: processcontrol.py [OPTION=ARGUMENT, [...]]")
    print("Stops, starts, or reports the status of WebLogic AdminServer or NodeManager processes.")
    print("Options:\n")
    print("   --start={target}      Invokes start process for the given target")
    print("   --stop={target}       Stops/kills the given target process")
    print("   --status={target}     Returns the running status of the given target")
    print("   -h, --help            Displays this help message")
    print("\nAvailable Targets: admin, nodemanager")
    
if __name__ == "__main__":
    # Chop off first argument, as we don't need it for anything
    status = main(sys.argv[1:])
    sys.exit(status)
